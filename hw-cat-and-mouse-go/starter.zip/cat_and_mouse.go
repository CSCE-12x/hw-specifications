package main

import (
	"os"
)

func main() {
	Main(os.Stdin, os.Stdout)
}
