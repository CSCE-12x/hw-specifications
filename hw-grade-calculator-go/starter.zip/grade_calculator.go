package main

import "fmt"

func main() {
	// TODO(student): design and implement a grade calculator for CSCE 120.
	fmt.Println("not yet implemented")
}
